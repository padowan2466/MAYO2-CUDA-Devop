#ifndef AES_CU_H
#define AES_CU_H

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdalign.h>

#define AES128_NROUNDS 10
#define AES128_COMP_SKEY_WORDS 22
#define AES128_SK_EXP_WORDS 88

#define MAYO_2_m_vec_limbs_AES 4
#define MAYO_2_m_bytes_AES 32


__device__ __constant__ unsigned char Rcon_device[10] = {
    0x01, 0x02, 0x04, 0x08, 0x10,
    0x20, 0x40, 0x80, 0x1B, 0x36
};

__device__ __forceinline__ uint32_t br_dec32le_device(
    const unsigned char *src
)
{
    return (uint32_t)src[0]
        | ((uint32_t)src[1] << 8)
        | ((uint32_t)src[2] << 16)
        | ((uint32_t)src[3] << 24);
}

__device__ __forceinline__ void br_aes_ct64_ortho_device(uint64_t *q)
{
#define SWAPN_DEV(cl, ch, s, x, y) do {                      \
        uint64_t a = (x);                                     \
        uint64_t b = (y);                                     \
        (x) = (a & (uint64_t)(cl)) | ((b & (uint64_t)(cl)) << (s)); \
        (y) = ((a & (uint64_t)(ch)) >> (s)) | (b & (uint64_t)(ch)); \
    } while (0)

#define SWAP2_DEV(x, y) SWAPN_DEV(0x5555555555555555ULL, 0xAAAAAAAAAAAAAAAAULL, 1, x, y)
#define SWAP4_DEV(x, y) SWAPN_DEV(0x3333333333333333ULL, 0xCCCCCCCCCCCCCCCCULL, 2, x, y)
#define SWAP8_DEV(x, y) SWAPN_DEV(0x0F0F0F0F0F0F0F0FULL, 0xF0F0F0F0F0F0F0F0ULL, 4, x, y)

    SWAP2_DEV(q[0], q[1]);
    SWAP2_DEV(q[2], q[3]);
    SWAP2_DEV(q[4], q[5]);
    SWAP2_DEV(q[6], q[7]);

    SWAP4_DEV(q[0], q[2]);
    SWAP4_DEV(q[1], q[3]);
    SWAP4_DEV(q[4], q[6]);
    SWAP4_DEV(q[5], q[7]);

    SWAP8_DEV(q[0], q[4]);
    SWAP8_DEV(q[1], q[5]);
    SWAP8_DEV(q[2], q[6]);
    SWAP8_DEV(q[3], q[7]);

#undef SWAPN_DEV
#undef SWAP2_DEV
#undef SWAP4_DEV
#undef SWAP8_DEV
}

__device__ __forceinline__ void br_aes_ct64_interleave_in_device(
    uint64_t *q0,
    uint64_t *q1,
    const uint32_t *w
)
{
    uint64_t x0, x1, x2, x3;

    x0 = w[0];
    x1 = w[1];
    x2 = w[2];
    x3 = w[3];

    x0 |= (x0 << 16);
    x1 |= (x1 << 16);
    x2 |= (x2 << 16);
    x3 |= (x3 << 16);

    x0 &= 0x0000FFFF0000FFFFULL;
    x1 &= 0x0000FFFF0000FFFFULL;
    x2 &= 0x0000FFFF0000FFFFULL;
    x3 &= 0x0000FFFF0000FFFFULL;

    x0 |= (x0 << 8);
    x1 |= (x1 << 8);
    x2 |= (x2 << 8);
    x3 |= (x3 << 8);

    x0 &= 0x00FF00FF00FF00FFULL;
    x1 &= 0x00FF00FF00FF00FFULL;
    x2 &= 0x00FF00FF00FF00FFULL;
    x3 &= 0x00FF00FF00FF00FFULL;

    *q0 = x0 | (x2 << 8);
    *q1 = x1 | (x3 << 8);
}

__device__ __forceinline__ void br_aes_ct64_bitslice_Sbox_device(uint64_t *q)
{
    /*
     * This S-box implementation is a straightforward translation of
     * the circuit described by Boyar and Peralta in "A new
     * combinational logic minimization technique with applications
     * to cryptology" (https://eprint.iacr.org/2009/191.pdf).
     *
     * Note that variables x* (input) and s* (output) are numbered
     * in "reverse" order (x0 is the high bit, x7 is the low bit).
     */

    uint64_t x0, x1, x2, x3, x4, x5, x6, x7;
    uint64_t y1, y2, y3, y4, y5, y6, y7, y8, y9;
    uint64_t y10, y11, y12, y13, y14, y15, y16, y17, y18, y19;
    uint64_t y20, y21;
    uint64_t z0, z1, z2, z3, z4, z5, z6, z7, z8, z9;
    uint64_t z10, z11, z12, z13, z14, z15, z16, z17;
    uint64_t t0, t1, t2, t3, t4, t5, t6, t7, t8, t9;
    uint64_t t10, t11, t12, t13, t14, t15, t16, t17, t18, t19;
    uint64_t t20, t21, t22, t23, t24, t25, t26, t27, t28, t29;
    uint64_t t30, t31, t32, t33, t34, t35, t36, t37, t38, t39;
    uint64_t t40, t41, t42, t43, t44, t45, t46, t47, t48, t49;
    uint64_t t50, t51, t52, t53, t54, t55, t56, t57, t58, t59;
    uint64_t t60, t61, t62, t63, t64, t65, t66, t67;
    uint64_t s0, s1, s2, s3, s4, s5, s6, s7;

    x0 = q[7];
    x1 = q[6];
    x2 = q[5];
    x3 = q[4];
    x4 = q[3];
    x5 = q[2];
    x6 = q[1];
    x7 = q[0];

    /*
     * Top linear transformation.
     */
    y14 = x3 ^ x5;
    y13 = x0 ^ x6;
    y9 = x0 ^ x3;
    y8 = x0 ^ x5;
    t0 = x1 ^ x2;
    y1 = t0 ^ x7;
    y4 = y1 ^ x3;
    y12 = y13 ^ y14;
    y2 = y1 ^ x0;
    y5 = y1 ^ x6;
    y3 = y5 ^ y8;
    t1 = x4 ^ y12;
    y15 = t1 ^ x5;
    y20 = t1 ^ x1;
    y6 = y15 ^ x7;
    y10 = y15 ^ t0;
    y11 = y20 ^ y9;
    y7 = x7 ^ y11;
    y17 = y10 ^ y11;
    y19 = y10 ^ y8;
    y16 = t0 ^ y11;
    y21 = y13 ^ y16;
    y18 = x0 ^ y16;

    /*
     * Non-linear section.
     */
    t2 = y12 & y15;
    t3 = y3 & y6;
    t4 = t3 ^ t2;
    t5 = y4 & x7;
    t6 = t5 ^ t2;
    t7 = y13 & y16;
    t8 = y5 & y1;
    t9 = t8 ^ t7;
    t10 = y2 & y7;
    t11 = t10 ^ t7;
    t12 = y9 & y11;
    t13 = y14 & y17;
    t14 = t13 ^ t12;
    t15 = y8 & y10;
    t16 = t15 ^ t12;
    t17 = t4 ^ t14;
    t18 = t6 ^ t16;
    t19 = t9 ^ t14;
    t20 = t11 ^ t16;
    t21 = t17 ^ y20;
    t22 = t18 ^ y19;
    t23 = t19 ^ y21;
    t24 = t20 ^ y18;

    t25 = t21 ^ t22;
    t26 = t21 & t23;
    t27 = t24 ^ t26;
    t28 = t25 & t27;
    t29 = t28 ^ t22;
    t30 = t23 ^ t24;
    t31 = t22 ^ t26;
    t32 = t31 & t30;
    t33 = t32 ^ t24;
    t34 = t23 ^ t33;
    t35 = t27 ^ t33;
    t36 = t24 & t35;
    t37 = t36 ^ t34;
    t38 = t27 ^ t36;
    t39 = t29 & t38;
    t40 = t25 ^ t39;

    t41 = t40 ^ t37;
    t42 = t29 ^ t33;
    t43 = t29 ^ t40;
    t44 = t33 ^ t37;
    t45 = t42 ^ t41;
    z0 = t44 & y15;
    z1 = t37 & y6;
    z2 = t33 & x7;
    z3 = t43 & y16;
    z4 = t40 & y1;
    z5 = t29 & y7;
    z6 = t42 & y11;
    z7 = t45 & y17;
    z8 = t41 & y10;
    z9 = t44 & y12;
    z10 = t37 & y3;
    z11 = t33 & y4;
    z12 = t43 & y13;
    z13 = t40 & y5;
    z14 = t29 & y2;
    z15 = t42 & y9;
    z16 = t45 & y14;
    z17 = t41 & y8;

    /*
     * Bottom linear transformation.
     */
    t46 = z15 ^ z16;
    t47 = z10 ^ z11;
    t48 = z5 ^ z13;
    t49 = z9 ^ z10;
    t50 = z2 ^ z12;
    t51 = z2 ^ z5;
    t52 = z7 ^ z8;
    t53 = z0 ^ z3;
    t54 = z6 ^ z7;
    t55 = z16 ^ z17;
    t56 = z12 ^ t48;
    t57 = t50 ^ t53;
    t58 = z4 ^ t46;
    t59 = z3 ^ t54;
    t60 = t46 ^ t57;
    t61 = z14 ^ t57;
    t62 = t52 ^ t58;
    t63 = t49 ^ t58;
    t64 = z4 ^ t59;
    t65 = t61 ^ t62;
    t66 = z1 ^ t63;
    s0 = t59 ^ t63;
    s6 = t56 ^ ~t62;
    s7 = t48 ^ ~t60;
    t67 = t64 ^ t65;
    s3 = t53 ^ t66;
    s4 = t51 ^ t66;
    s5 = t47 ^ t65;
    s1 = t64 ^ ~s3;
    s2 = t55 ^ ~t67;

    q[7] = s0;
    q[6] = s1;
    q[5] = s2;
    q[4] = s3;
    q[3] = s4;
    q[2] = s5;
    q[1] = s6;
    q[0] = s7;
}


__device__ __forceinline__ uint32_t sub_word_device(uint32_t x)
{
    uint64_t q[8];

    q[0] = x;
    q[1] = 0;
    q[2] = 0;
    q[3] = 0;
    q[4] = 0;
    q[5] = 0;
    q[6] = 0;
    q[7] = 0;

    br_aes_ct64_ortho_device(q);
    br_aes_ct64_bitslice_Sbox_device(q);
    br_aes_ct64_ortho_device(q);

    return (uint32_t)q[0];
}

__device__ void br_aes_ct64_keysched_device(
    uint64_t *comp_skey,
    const unsigned char *key
)
{
    unsigned int i, j, k;
    uint32_t tmp;
    uint32_t skey[44];   

   
    skey[0] = br_dec32le_device(key + 0);
    skey[1] = br_dec32le_device(key + 4);
    skey[2] = br_dec32le_device(key + 8);
    skey[3] = br_dec32le_device(key + 12);

    tmp = skey[3];

    for (i = 4, j = 0, k = 0; i < 44; i++) {
        if (j == 0) {
            tmp = (tmp << 24) | (tmp >> 8);
            tmp = sub_word_device(tmp) ^ (uint32_t)Rcon_device[k];
        }

        tmp ^= skey[i - 4];
        skey[i] = tmp;

        if (++j == 4) {
            j = 0;
            k++;
        }
    }

    
    for (i = 0, j = 0; i < 44; i += 4, j += 2) {
        uint64_t q[8];

        br_aes_ct64_interleave_in_device(&q[0], &q[4], skey + i);

        q[1] = q[0];
        q[2] = q[0];
        q[3] = q[0];
        q[5] = q[4];
        q[6] = q[4];
        q[7] = q[4];

        br_aes_ct64_ortho_device(q);

        comp_skey[j + 0] =
            (q[0] & 0x1111111111111111ULL)
          | (q[1] & 0x2222222222222222ULL)
          | (q[2] & 0x4444444444444444ULL)
          | (q[3] & 0x8888888888888888ULL);

        comp_skey[j + 1] =
            (q[4] & 0x1111111111111111ULL)
          | (q[5] & 0x2222222222222222ULL)
          | (q[6] & 0x4444444444444444ULL)
          | (q[7] & 0x8888888888888888ULL);
    }
}

__device__ void br_aes_ct64_skey_expand_device(
    uint64_t *skey,
    const uint64_t *comp_skey
)
{
    unsigned int u, v;

    
    for (u = 0, v = 0; u < 22; u++, v += 4) {
        uint64_t x0, x1, x2, x3;

        x0 = comp_skey[u];
        x1 = comp_skey[u];
        x2 = comp_skey[u];
        x3 = comp_skey[u];

        x0 &= 0x1111111111111111ULL;
        x1 &= 0x2222222222222222ULL;
        x2 &= 0x4444444444444444ULL;
        x3 &= 0x8888888888888888ULL;

        x1 >>= 1;
        x2 >>= 2;
        x3 >>= 3;

        skey[v + 0] = (x0 << 4) - x0;
        skey[v + 1] = (x1 << 4) - x1;
        skey[v + 2] = (x2 << 4) - x2;
        skey[v + 3] = (x3 << 4) - x3;
    }
}

__device__ void aes128_key_expand_device(
    uint64_t *sk_exp,
    const unsigned char *key
)
{
    uint64_t comp_skey[AES128_COMP_SKEY_WORDS];

    br_aes_ct64_keysched_device(comp_skey, key);
    br_aes_ct64_skey_expand_device(sk_exp, comp_skey);
}



__global__ void aes128_key_expand_batch(
    const unsigned char *d_S,
    int S_stride,
    uint64_t *d_rkeys_batch,
    int batch_count
)
{
    int b = blockIdx.x * blockDim.x + threadIdx.x;

    if (b >= batch_count) return;

    const unsigned char *seed_pk_b =
        d_S + b * S_stride;

    uint64_t *sk_exp_b =
        d_rkeys_batch + b * AES128_SK_EXP_WORDS;

    aes128_key_expand_device(sk_exp_b, seed_pk_b);
}

__device__ __forceinline__ uint32_t br_swap32_device(uint32_t x)
{
    x = ((x & (uint32_t)0x00FF00FF) << 8)
        | ((x >> 8) & (uint32_t)0x00FF00FF);

    return (x << 16) | (x >> 16);
}

__device__ __forceinline__ void inc4_be_device(uint32_t *x)
{
    uint32_t t = br_swap32_device(*x) + 4;
    *x = br_swap32_device(t);
}

__device__ __forceinline__ void br_enc32le_device(
    unsigned char *dst,
    uint32_t x
)
{
    dst[0] = (unsigned char)x;
    dst[1] = (unsigned char)(x >> 8);
    dst[2] = (unsigned char)(x >> 16);
    dst[3] = (unsigned char)(x >> 24);
}

__device__ __forceinline__ void br_range_enc32le_device(
    unsigned char *dst,
    const uint32_t *v,
    int num
)
{
    for (int i = 0; i < num; i++) {
        br_enc32le_device(dst + 4 * i, v[i]);
    }
}

__device__ __forceinline__ void add_round_key_device(
    uint64_t *q,
    const uint64_t *sk
)
{
    q[0] ^= sk[0];
    q[1] ^= sk[1];
    q[2] ^= sk[2];
    q[3] ^= sk[3];
    q[4] ^= sk[4];
    q[5] ^= sk[5];
    q[6] ^= sk[6];
    q[7] ^= sk[7];
}

__device__ __forceinline__ void shift_rows_device(uint64_t *q)
{
    for (int i = 0; i < 8; i++) {
        uint64_t x = q[i];

        q[i] = (x & 0x000000000000FFFFULL)
             | ((x & 0x00000000FFF00000ULL) >> 4)
             | ((x & 0x00000000000F0000ULL) << 12)
             | ((x & 0x0000FF0000000000ULL) >> 8)
             | ((x & 0x000000FF00000000ULL) << 8)
             | ((x & 0xF000000000000000ULL) >> 12)
             | ((x & 0x0FFF000000000000ULL) << 4);
    }
}

__device__ __forceinline__ uint64_t rotr32_device(uint64_t x)
{
    return (x << 32) | (x >> 32);
}

__device__ __forceinline__ void mix_columns_device(uint64_t *q)
{
    uint64_t q0, q1, q2, q3, q4, q5, q6, q7;
    uint64_t r0, r1, r2, r3, r4, r5, r6, r7;

    q0 = q[0];
    q1 = q[1];
    q2 = q[2];
    q3 = q[3];
    q4 = q[4];
    q5 = q[5];
    q6 = q[6];
    q7 = q[7];

    r0 = (q0 >> 16) | (q0 << 48);
    r1 = (q1 >> 16) | (q1 << 48);
    r2 = (q2 >> 16) | (q2 << 48);
    r3 = (q3 >> 16) | (q3 << 48);
    r4 = (q4 >> 16) | (q4 << 48);
    r5 = (q5 >> 16) | (q5 << 48);
    r6 = (q6 >> 16) | (q6 << 48);
    r7 = (q7 >> 16) | (q7 << 48);

    q[0] = q7 ^ r7 ^ r0 ^ rotr32_device(q0 ^ r0);
    q[1] = q0 ^ r0 ^ q7 ^ r7 ^ r1 ^ rotr32_device(q1 ^ r1);
    q[2] = q1 ^ r1 ^ r2 ^ rotr32_device(q2 ^ r2);
    q[3] = q2 ^ r2 ^ q7 ^ r7 ^ r3 ^ rotr32_device(q3 ^ r3);
    q[4] = q3 ^ r3 ^ q7 ^ r7 ^ r4 ^ rotr32_device(q4 ^ r4);
    q[5] = q4 ^ r4 ^ r5 ^ rotr32_device(q5 ^ r5);
    q[6] = q5 ^ r5 ^ r6 ^ rotr32_device(q6 ^ r6);
    q[7] = q6 ^ r6 ^ r7 ^ rotr32_device(q7 ^ r7);
}

__device__ __forceinline__ void br_aes_ct64_interleave_out_device(
    uint32_t *w,
    uint64_t q0,
    uint64_t q1
)
{
    uint64_t x0, x1, x2, x3;

    x0 = q0 & 0x00FF00FF00FF00FFULL;
    x1 = q1 & 0x00FF00FF00FF00FFULL;
    x2 = (q0 >> 8) & 0x00FF00FF00FF00FFULL;
    x3 = (q1 >> 8) & 0x00FF00FF00FF00FFULL;

    x0 |= (x0 >> 8);
    x1 |= (x1 >> 8);
    x2 |= (x2 >> 8);
    x3 |= (x3 >> 8);

    x0 &= 0x0000FFFF0000FFFFULL;
    x1 &= 0x0000FFFF0000FFFFULL;
    x2 &= 0x0000FFFF0000FFFFULL;
    x3 &= 0x0000FFFF0000FFFFULL;

    w[0] = (uint32_t)x0 | (uint32_t)(x0 >> 16);
    w[1] = (uint32_t)x1 | (uint32_t)(x1 >> 16);
    w[2] = (uint32_t)x2 | (uint32_t)(x2 >> 16);
    w[3] = (uint32_t)x3 | (uint32_t)(x3 >> 16);
}

__device__ void aes_ecb4x_device(
    unsigned char *out,
    const uint32_t ivw[16],
    const uint64_t *sk_exp,
    unsigned int nrounds
)
{
    uint32_t w[16];
    uint64_t q[8];

    
    for (int i = 0; i < 16; i++) {
        w[i] = ivw[i];
    }

    for (int i = 0; i < 4; i++) {
        br_aes_ct64_interleave_in_device(
            &q[i],
            &q[i + 4],
            w + (i << 2)
        );
    }

    br_aes_ct64_ortho_device(q);

    add_round_key_device(q, sk_exp);

    for (int i = 1; i < nrounds; i++) {
        br_aes_ct64_bitslice_Sbox_device(q);
        shift_rows_device(q);
        mix_columns_device(q);
        add_round_key_device(q, sk_exp + (i << 3));
    }

    br_aes_ct64_bitslice_Sbox_device(q);
    shift_rows_device(q);
    add_round_key_device(q, sk_exp + 8 * nrounds);

    br_aes_ct64_ortho_device(q);

    for (int i = 0; i < 4; i++) {
        br_aes_ct64_interleave_out_device(
            w + (i << 2),
            q[i],
            q[i + 4]
        );
    }

    br_range_enc32le_device(out, w, 16);
}

__device__ __forceinline__ void aes_ctr4x_device(
    unsigned char *out,
    uint32_t ivw[16],
    const uint64_t *sk_exp,
    unsigned int nrounds
)
{
    aes_ecb4x_device(out, ivw, sk_exp, nrounds);

    
    inc4_be_device(ivw + 3);
    inc4_be_device(ivw + 7);
    inc4_be_device(ivw + 11);
    inc4_be_device(ivw + 15);
}

__global__ void aes128_ctr4x_batch(
    unsigned char *d_P_packed,
    int packed_bytes,
    const uint64_t *d_rkeys_batch,
    int groups_per_batch,
    int batch_count
)
{
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    int b = tid / groups_per_batch;
    int group_id = tid % groups_per_batch;

    if (b >= batch_count) return;

    unsigned char *P_b =
        d_P_packed + b * packed_bytes;

    const uint64_t *sk_exp_b =
        d_rkeys_batch + b * AES128_SK_EXP_WORDS;

    int out_offset = group_id * 64;

    uint32_t cc = group_id * 4;

    uint32_t ivw[16];

    
    ivw[0]  = 0;
    ivw[1]  = 0;
    ivw[2]  = 0;
    ivw[4]  = 0;
    ivw[5]  = 0;
    ivw[6]  = 0;
    ivw[8]  = 0;
    ivw[9]  = 0;
    ivw[10] = 0;
    ivw[12] = 0;
    ivw[13] = 0;
    ivw[14] = 0;

    ivw[3]  = br_swap32_device(cc);
    ivw[7]  = br_swap32_device(cc + 1);
    ivw[11] = br_swap32_device(cc + 2);
    ivw[15] = br_swap32_device(cc + 3);

    aes_ctr4x_device(
        P_b + out_offset,
        ivw,
        sk_exp_b,
        AES128_NROUNDS
    );
}


__global__ void unpack_m_vecs_batch(
    const unsigned char *d_P_packed,
    uint64_t *d_P_unpacked,
    int packed_bytes,
    int total_vecs,
    int batch_count
)
{
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    int b = tid / total_vecs;
    int vec_id = tid % total_vecs;

    if (b >= batch_count) return;

    const unsigned char *P_packed_b =
        d_P_packed + b * packed_bytes;

    uint64_t *P_unpacked_b =
        d_P_unpacked + b * total_vecs * MAYO_2_m_vec_limbs_AES;

    const unsigned char *src =
        P_packed_b + vec_id * MAYO_2_m_bytes_AES;

    uint64_t *dst =
        P_unpacked_b + vec_id * MAYO_2_m_vec_limbs_AES;

    for (int limb = 0; limb < MAYO_2_m_vec_limbs_AES; limb++) {
        uint64_t acc = 0;

        for (int j = 0; j < 16; j++) {
            int coeff_idx = limb * 16 + j;
            int byte_idx = coeff_idx >> 1;

            unsigned char byte = src[byte_idx];

            unsigned char coeff;

            if ((coeff_idx & 1) == 0) {
                coeff = byte & 0x0F;
            } else {
                coeff = byte >> 4;
            }

            acc |= ((uint64_t)coeff) << (4 * j);
        }

        dst[limb] = acc;
    }
}
#endif